module.exports = {
  Token: "8056998180:AAG2SjNahF6yz4HF6Q10pU5DvqcejJj43bg",
  owner: "6498443469",
};